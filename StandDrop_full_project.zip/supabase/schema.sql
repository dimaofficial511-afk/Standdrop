-- StandDrop: virtual-only demo economy. Run in Supabase SQL Editor.
create extension if not exists pgcrypto;
create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 username text not null unique,
 balance bigint not null default 10000 check(balance >= 0),
 last_daily date,
 created_at timestamptz not null default now()
);
create table if not exists public.inventory (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references public.profiles(id) on delete cascade,
 item_name text not null,
 rarity text not null,
 created_at timestamptz not null default now()
);
create table if not exists public.promo_codes (
 code text primary key,
 reward bigint not null check(reward > 0),
 max_uses integer not null default 1000,
 uses integer not null default 0,
 active boolean not null default true
);
create table if not exists public.promo_redemptions (
 user_id uuid references public.profiles(id) on delete cascade,
 code text references public.promo_codes(code),
 created_at timestamptz default now(),
 primary key(user_id,code)
);
create table if not exists public.transactions (
 id uuid primary key default gen_random_uuid(),
 user_id uuid references public.profiles(id) on delete cascade,
 kind text not null,
 amount bigint not null,
 details jsonb not null default '{}',
 created_at timestamptz default now()
);
alter table public.profiles enable row level security;
alter table public.inventory enable row level security;
alter table public.promo_codes enable row level security;
alter table public.promo_redemptions enable row level security;
alter table public.transactions enable row level security;
create policy "read own profile" on public.profiles for select using(auth.uid()=id);
create policy "read own inventory" on public.inventory for select using(auth.uid()=user_id);
create policy "read own transactions" on public.transactions for select using(auth.uid()=user_id);
-- No client-side writes to balance, inventory, promo uses or transactions.
create or replace function public.new_profile() returns trigger language plpgsql security definer set search_path=public as $$
declare uname text;
begin
 uname:=coalesce(nullif(new.raw_user_meta_data->>'username',''),'Player_'||substr(new.id::text,1,8));
 insert into public.profiles(id,username) values(new.id,uname);
 return new;
end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.new_profile();
insert into public.promo_codes(code,reward,max_uses) values('DROP100',100,10000) on conflict do nothing;
create or replace function public.open_case(p_case_id text) returns text language plpgsql security definer set search_path=public as $$
declare uid uuid:=auth.uid(); price bigint; nm text; rar text; roll integer;
begin
 if uid is null then raise exception 'Сначала войдите в аккаунт'; end if;
 price:=case p_case_id when 'starter' then 100 when 'neon' then 500 when 'royal' then 1500 else null end;
 if price is null then raise exception 'Неизвестный кейс'; end if;
 update profiles set balance=balance-price where id=uid and balance>=price;
 if not found then raise exception 'Недостаточно виртуальных монет'; end if;
 roll:=floor(random()*100)::int;
 if roll<65 then nm:='Граффити'; rar:='Обычный';
 elsif roll<90 then nm:='Наклейка'; rar:='Редкий';
 elsif roll<98 then nm:='Перчатки'; rar:='Эпический';
 else nm:='Неоновый нож'; rar:='Легендарный'; end if;
 insert into inventory(user_id,item_name,rarity) values(uid,nm,rar);
 insert into transactions(user_id,kind,amount,details) values(uid,'case_open',-price,jsonb_build_object('case',p_case_id,'item',nm,'rarity',rar));
 return 'Выпало: '||nm||' ('||rar||')';
end; $$;
create or replace function public.claim_daily_bonus() returns text language plpgsql security definer set search_path=public as $$
declare uid uuid:=auth.uid();
begin
 if uid is null then raise exception 'Войдите в аккаунт'; end if;
 update profiles set balance=balance+1000,last_daily=current_date where id=uid and (last_daily is null or last_daily<current_date);
 if not found then raise exception 'Бонус уже получен сегодня'; end if;
 insert into transactions(user_id,kind,amount) values(uid,'daily_bonus',1000);
 return 'Получено +1 000 G';
end; $$;
create or replace function public.redeem_promo(p_code text) returns text language plpgsql security definer set search_path=public as $$
declare uid uuid:=auth.uid(); reward_amount bigint;
begin
 if uid is null then raise exception 'Войдите в аккаунт'; end if;
 select reward into reward_amount from promo_codes where code=upper(trim(p_code)) and active and uses<max_uses for update;
 if reward_amount is null then raise exception 'Промокод недействителен или закончился'; end if;
 insert into promo_redemptions(user_id,code) values(uid,upper(trim(p_code)));
 update promo_codes set uses=uses+1 where code=upper(trim(p_code));
 update profiles set balance=balance+reward_amount where id=uid;
 insert into transactions(user_id,kind,amount,details) values(uid,'promo',reward_amount,jsonb_build_object('code',upper(trim(p_code))));
 return 'Промокод активирован: +'||reward_amount||' G';
exception when unique_violation then raise exception 'Этот промокод уже использован'; end; $$;
grant execute on function public.open_case(text) to authenticated;
grant execute on function public.claim_daily_bonus() to authenticated;
grant execute on function public.redeem_promo(text) to authenticated;
