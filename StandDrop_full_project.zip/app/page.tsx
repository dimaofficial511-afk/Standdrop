"use client";
import {useEffect,useState} from "react";
import {supabase} from "../lib/supabase";
type CaseItem={id:string;name:string;price:number;emoji:string;description:string};
type Profile={username:string;balance:number};
const cases:CaseItem[]=[
{id:"starter",name:"Стартовый",price:100,emoji:"📦",description:"Небольшой шанс на редкий предмет"},
{id:"neon",name:"Неоновый",price:500,emoji:"💜",description:"Яркие предметы и редкие выпадения"},
{id:"royal",name:"Королевский",price:1500,emoji:"👑",description:"Кейс для больших виртуальных ставок"}
];
export default function Home(){
 const db=supabase(); const [user,setUser]=useState<any>(null); const [profile,setProfile]=useState<Profile|null>(null);
 const [email,setEmail]=useState(""); const [password,setPassword]=useState(""); const [username,setUsername]=useState("");
 const [tab,setTab]=useState("cases"); const [inventory,setInventory]=useState<any[]>([]); const [promo,setPromo]=useState("");
 const [message,setMessage]=useState("Войди или создай аккаунт. Тестовые монеты не имеют денежной стоимости.");
 const [busy,setBusy]=useState(false);
 async function refresh(u:any){if(!u)return; const {data:p}=await db.from("profiles").select("username,balance").eq("id",u.id).single(); if(p)setProfile(p);
 const {data:i}=await db.from("inventory").select("id,item_name,rarity,created_at").eq("user_id",u.id).order("created_at",{ascending:false});setInventory(i||[]);}
 useEffect(()=>{db.auth.getUser().then(({data})=>{setUser(data.user);if(data.user)refresh(data.user)});const {data:sub}=db.auth.onAuthStateChange((_e,s)=>{setUser(s?.user||null);if(s?.user)refresh(s.user);else{setProfile(null);setInventory([])}});return()=>sub.subscription.unsubscribe()},[]);
 async function auth(mode:"in"|"up"){setBusy(true);setMessage("");try{const r=mode==="up"?await db.auth.signUp({email,password,options:{data:{username}}}):await db.auth.signInWithPassword({email,password});if(r.error)throw r.error;if(r.data.user){setUser(r.data.user);await refresh(r.data.user);setMessage(mode==="up"?"Аккаунт создан. Если включено подтверждение почты, проверь почту.":"Вход выполнен.")}}catch(e:any){setMessage(e.message)}finally{setBusy(false)}}
 async function action(fn:string,args:any={}){if(!user){setMessage("Сначала войди в аккаунт.");return}setBusy(true);try{const {data,error}=await db.rpc(fn,args);if(error)throw error;setMessage(typeof data==="string"?data:JSON.stringify(data));await refresh(user)}catch(e:any){setMessage(e.message)}finally{setBusy(false)}}
 async function openCase(c:CaseItem){await action("open_case",{p_case_id:c.id})}
 return <main className="shell"><header><div className="brand"><span className="logo">S</span><div><b>STAND<span>DROP</span></b><small>VIRTUAL CASE ARENA</small></div></div><div className="balance">🪙 {profile?.balance?.toLocaleString("ru-RU")??"—"} G</div></header>
 {!user?<section className="auth panel"><div><p className="eyebrow">ТВОЯ ИГРОВАЯ ЗОНА</p><h1>Открывай.<br/><span>Собирай.</span> Побеждай.</h1><p className="muted">Создай аккаунт, чтобы сохранить баланс и инвентарь.</p></div><div className="authform"><input placeholder="Никнейм (для регистрации)" value={username} onChange={e=>setUsername(e.target.value)}/><input placeholder="Email" type="email" value={email} onChange={e=>setEmail(e.target.value)}/><input placeholder="Пароль (от 6 символов)" type="password" value={password} onChange={e=>setPassword(e.target.value)}/><button disabled={busy} onClick={()=>auth("up")}>Создать аккаунт</button><button className="secondary" disabled={busy} onClick={()=>auth("in")}>Войти</button></div></section>:<><nav>{[["cases","Кейсы"],["inventory","Инвентарь"],["bonus","Бонус"],["promo","Промокод"]].map(([v,l])=><button key={v} className={tab===v?"active":""} onClick={()=>setTab(v)}>{l}</button>)}<button className="logout" onClick={()=>db.auth.signOut()}>Выйти</button></nav>
 {tab==="cases"&&<><section className="hero panel"><div><p className="eyebrow">STANDDROP CASE ARENA</p><h1>ТВОЯ УДАЧА.<br/><span>ТВОИ ПРАВИЛА.</span></h1><p className="muted">Виртуальные кейсы, предметы и соревнования.</p></div><div className="orb">✦</div></section><h2>Выбери кейс</h2><div className="casegrid">{cases.map(c=><article className="case panel" key={c.id}><div className="caseemoji">{c.emoji}</div><h3>{c.name}</h3><p className="muted">{c.description}</p><button disabled={busy} onClick={()=>openCase(c)}>Открыть · {c.price} G</button></article>)}</div></>}
 {tab==="inventory"&&<><h2>Твой инвентарь</h2><div className="casegrid">{inventory.length?inventory.map(i=><article className="panel item" key={i.id}><div className="caseemoji">🎁</div><b>{i.item_name}</b><small>{i.rarity}</small></article>):<p className="muted">Пока пусто. Открой первый кейс.</p>}</div></>}
 {tab==="bonus"&&<section className="panel feature"><h2>Ежедневный бонус</h2><p className="muted">Получай виртуальные монеты раз в сутки.</p><button disabled={busy} onClick={()=>action("claim_daily_bonus")}>Забрать +1 000 G</button></section>}
 {tab==="promo"&&<section className="panel feature"><h2>Промокод</h2><input placeholder="Введи промокод" value={promo} onChange={e=>setPromo(e.target.value.toUpperCase())}/><button disabled={busy} onClick={()=>action("redeem_promo",{p_code:promo})}>Активировать</button><p className="muted">Демо-код для проверки: DROP100</p></section>}
 </>}
 <div className="notice">{message}</div><footer>STANDDROP © 2026 · Фан-проект, не связан с разработчиками Standoff 2. Все монеты и предметы виртуальные, без вывода и обмена на деньги.</footer></main>
}