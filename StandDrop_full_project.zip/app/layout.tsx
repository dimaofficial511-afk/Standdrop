import type { Metadata } from "next";
import "./style.css";
export const metadata: Metadata = {title:"StandDrop",description:"Открывай виртуальные кейсы, собирай инвентарь и участвуй в батлах."};
export default function RootLayout({children}:{children:React.ReactNode}) { return <html lang="ru"><body>{children}</body></html>; }